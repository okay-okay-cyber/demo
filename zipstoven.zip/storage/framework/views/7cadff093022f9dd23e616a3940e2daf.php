
<?php $__env->startSection('content'); ?>
<div class="=col-lg-12 col-md-12">
    <h1>Programs</h1>
    <h2>Program Name: -<?php echo e($program->name); ?></h2>
    <h3>Product description: -<?php echo e($program->description); ?></h3>
    <h4>Program Exercise Name: -<?php echo e($program ->exercise); ?></h4>
<div>
<img src="<?php echo e(asset('storage/'.$program->photo)); ?>" width="50" height="50"/>
</div>
</div>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/program/view.blade.php ENDPATH**/ ?>