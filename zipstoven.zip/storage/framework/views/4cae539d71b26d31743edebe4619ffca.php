
<?php $__env->startSection('content'); ?>
<div class="=col-lg-12 col-md-12">
    <h1>Workouts</h1>
    <h2>Workout Name: -<?php echo e($workout->name); ?></h2>
    <h3>Workout description: -<?php echo e($workout->description); ?></h3>
    <h4>Workout Exercise Name: -<?php echo e($workout ->exercise); ?></h4>
<div>
<img src="<?php echo e(asset('storage/'.$workout->photo)); ?>" width="50" height="50"/>
</div>
</div>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/auth/workout/view.blade.php ENDPATH**/ ?>