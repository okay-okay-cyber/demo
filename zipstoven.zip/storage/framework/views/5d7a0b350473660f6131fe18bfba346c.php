

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li style="color:red"><?php echo e($error); ?></li>        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<body>
    <form action="<?php echo e(route('program.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    <div class="container mt-5">
        <h1 class="mb-4">Program Form</h1>
        <form>
            <div class="mb-3">
                <label for="programName" class="form-label">Name</label>
                <input type="text" name="name"class="form-control" id="programName" placeholder="Enter program name">
            </div>
            <div class="mb-3">
                <label for="programDescription" class="form-label">Description</label>
                <textarea class="form-control" name="description" id="programDescription" rows="3" placeholder="Enter program description"></textarea>
            </div>
            <div class="mb-3">
                <label for="duration_days" class="form-label">Duration Days</label>
                <input type="number" name="duration_days"class="form-control" id="duration_days" placeholder="Enter duration day">
            </div>
            <div class="mb-3">
                <label for="programPhoto" class="form-label">Photo</label>
                <input class="form-control"  name="photo" type="file" id="programPhoto">
            </div>
            <div class="mb-3">
                <label for="programExercise" class="form-label">Exercise</label>
                <select class="form-select" name="exercise_id" id="programExercise">
                    <option disabled>Choose a exercise</option>
                    <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($exercise->id); ?>"><?php echo e($exercise->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Action</label>
                <div class="d-flex">
                    <button type="submit" class="btn btn-primary me-2">Submit</button>
                    <button type="reset" class="btn btn-secondary">Cancel</button>
                </div>
            </div>
        </form>
    </div>
    </body>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/program/form.blade.php ENDPATH**/ ?>