
<?php $__env->startSection('content'); ?>
<div class="=col-lg-12 col-md-12">
    
    <h1>Exercises</h1>
    <h2>Exercise Id</h2>
    <h3>Exercise Name: -<?php echo e($exercise->name); ?></h3>
<div>
<img src="<?php echo e(asset('storage/'.$exercise->photo)); ?>" width="50" height="50"/>
</div>
</div>
<?php $__env->stopSection(); ?>  
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/auth/exercise/view.blade.php ENDPATH**/ ?>