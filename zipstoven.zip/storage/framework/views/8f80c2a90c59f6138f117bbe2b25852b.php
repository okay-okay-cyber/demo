
<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li style="color:red"><?php echo e($error); ?></li>        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<body>
    <form action="<?php echo e(route('exercise.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    <div class="container mt-5">
        <h1 class="mb-4">Exercise Form</h1>
        <form>
            <div class="mb-3">
                <label for="exerciseId" class="form-label">ID</label>
                <input type="text" name="id"class="form-control" id="exerciseId" placeholder="Enter Exercise Id">
            </div>
            <div class="mb-3">
                <label for="exerciseName" class="form-label">Name</label>
                <input type="text" name="name"class="form-control" id="exerciseName" placeholder="Enter Exercise name">
            </div>
            <div class="mb-3">
                <label for="exercisePhoto" class="form-label">Photo</label>
                <input class="form-control"  name="photo" type="file" id="exercisePhoto">
            </div>
            <div class="mb-3">
                <label class="form-label">Action</label>
                <div class="d-flex">
                    <button type="submit" class="btn btn-primary me-2">Submit</button>
                    <button type="reset" class="btn btn-secondary">Cancel</button>
                </div>
            </div>
        </form>
    </div>
    </body>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/auth/exercise/form.blade.php ENDPATH**/ ?>