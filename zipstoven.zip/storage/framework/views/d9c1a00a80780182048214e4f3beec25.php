
<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li style="color:red"><?php echo e($error); ?></li>        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<body>
    <form action="<?php echo e(route('auth.workout.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    <div class="container mt-5">
        <h1 class="mb-4">Workout Form</h1>
        <form>
            <div class="mb-3">
                <label for="workoutName" class="form-label">Name</label>
                <input type="text" name="name"class="form-control" id="workoutName" placeholder="Enter workout name">
            </div>
            <div class="mb-3">
                <label for="workoutDescription" class="form-label">Description</label>
                <textarea class="form-control" name="description" id="workoutDescription" rows="3" placeholder="Enter workout description"></textarea>
            </div>
            <div class="mb-3">
                <label for="workoutPhoto" class="form-label">Photo</label>
                <input class="form-control"  name="photo" type="file" id="workoutPhoto">
            </div>
            <div class="mb-3">
                <label for="workoutExercise" class="form-label">Exercise</label>
                <select class="form-select" name="exercise_id" id="workoutExercise">
                    <option disabled>Choose a exercise</option>
                    <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($exercise->id); ?>"><?php echo e($exercise->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Action</label>
                <div class="d-flex">
                    <button type="submit" class="btn btn-primary me-2">Submit</button>
                    <button type="reset" class="btn btn-secondary">Cancel</button>
                </div>
            </div>
        </form>
    </div>
    </body>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/auth/workout/form.blade.php ENDPATH**/ ?>