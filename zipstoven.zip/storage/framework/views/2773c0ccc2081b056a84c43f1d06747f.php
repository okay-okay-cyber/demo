

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12">
    <h1>Workout</h1>
    <a href="<?php echo e(route ('workout.create')); ?>">
        <button>Create workout</button>
    </a>
    <?php if(Session::has('success')): ?>
    <div class="alert alert-success" role="alert">
      <?php echo e(session::get('success')); ?>

    </div>
      
    <?php endif; ?>
<table class="table">
    <thead>
      <tr>
        <th scope="col">id</th>
        <th scope="col">name</th>
        <th scope="col">description</th>
        <th scope="col">photo</th>
        <th scope="col">exercise</th>
      </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $workouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($workout->id); ?></td>
            <td><?php echo e($workout->name); ?></td>
            <td><?php echo e($workout->description); ?></td>
           <td> <img src="<?php echo e(asset('storage/'.$workout->photo)); ?>" alt="" width="50" height="50" /> </td>
           <td> <?php echo e($workout->exercise->name); ?> </td>
           <td>
            

            <form action=" <?php echo e(route('workout.show',$workout->id)); ?>"method="GET">
              <?php echo method_field('VIEW'); ?>
              <?php echo csrf_field(); ?>
              <button>View</button>
            
            </form>
          
            <form action=" <?php echo e(route('workout.edit',$workout->id)); ?>"method="GET">
              <?php echo method_field('EDIT'); ?>
              <?php echo csrf_field(); ?>
              <button>Edit</button>
              
            </form>

            <form action=" <?php echo e(route('workout.destroy',$workout->id)); ?>"method="POST">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
              <button>Delete</button>
              
            </form>
           </td>
          </tr>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <td>No data found</td>
        <?php endif; ?>
    

    </tbody>
  </table>
</div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\resources\views/auth/workout/index.blade.php ENDPATH**/ ?>